<?php

require( 'advanced-custom-fields/acf.php' );
require( 'navz-photo-gallery/navz-photo-gallery.php' );